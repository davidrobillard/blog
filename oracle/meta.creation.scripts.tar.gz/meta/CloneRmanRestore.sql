SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /u01/app/oracle/admin/meta/scripts/CloneRmanRestore.log append
startup nomount pfile="/u01/app/oracle/admin/meta/scripts/init.ora";
@/u01/app/oracle/admin/meta/scripts/rmanRestoreDatafiles.sql;
spool off
