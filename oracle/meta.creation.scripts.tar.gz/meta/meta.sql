set verify off
ACCEPT sysPassword CHAR PROMPT 'Enter new password for SYS: ' HIDE
ACCEPT systemPassword CHAR PROMPT 'Enter new password for SYSTEM: ' HIDE
ACCEPT sysmanPassword CHAR PROMPT 'Enter new password for SYSMAN: ' HIDE
ACCEPT dbsnmpPassword CHAR PROMPT 'Enter new password for DBSNMP: ' HIDE
host /u01/app/oracle/product/11.2.0.3/dbhome_1/bin/orapwd file=/u01/app/oracle/product/11.2.0.3/dbhome_1/dbs/orapwmeta force=y
@/u01/app/oracle/admin/meta/scripts/CloneRmanRestore.sql
@/u01/app/oracle/admin/meta/scripts/cloneDBCreation.sql
@/u01/app/oracle/admin/meta/scripts/postScripts.sql
@/u01/app/oracle/admin/meta/scripts/lockAccount.sql
@/u01/app/oracle/admin/meta/scripts/postDBCreation.sql
