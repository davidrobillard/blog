SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /u01/app/oracle/admin/meta/scripts/cloneDBCreation.log append
Create controlfile reuse set database "meta"
MAXINSTANCES 8
MAXLOGHISTORY 1
MAXLOGFILES 16
MAXLOGMEMBERS 3
MAXDATAFILES 100
Datafile 
'/u02/oradata/meta/system01.dbf',
'/u02/oradata/meta/sysaux01.dbf',
'/u02/oradata/meta/undotbs01.dbf',
'/u02/oradata/meta/users01.dbf'
LOGFILE GROUP 1 ('/u02/oradata/meta/redo01a.log', '/u03/oradata/meta/redo01b.log') SIZE 51200K,
GROUP 2 ('/u02/oradata/meta/redo02a.log', '/u03/oradata/meta/redo02b.log') SIZE 51200K,
GROUP 3 ('/u02/oradata/meta/redo03a.log', '/u03/oradata/meta/redo03b.log') SIZE 51200K RESETLOGS;
exec dbms_backup_restore.zerodbid(0);
shutdown immediate;
startup nomount pfile="/u01/app/oracle/admin/meta/scripts/initmetaTemp.ora";
Create controlfile reuse set database "meta"
MAXINSTANCES 8
MAXLOGHISTORY 1
MAXLOGFILES 16
MAXLOGMEMBERS 3
MAXDATAFILES 100
Datafile 
'/u02/oradata/meta/system01.dbf',
'/u02/oradata/meta/sysaux01.dbf',
'/u02/oradata/meta/undotbs01.dbf',
'/u02/oradata/meta/users01.dbf'
LOGFILE GROUP 1 ('/u02/oradata/meta/redo01a.log', '/u03/oradata/meta/redo01b.log') SIZE 51200K,
GROUP 2 ('/u02/oradata/meta/redo02a.log', '/u03/oradata/meta/redo02b.log') SIZE 51200K,
GROUP 3 ('/u02/oradata/meta/redo03a.log', '/u03/oradata/meta/redo03b.log') SIZE 51200K RESETLOGS;
alter system enable restricted session;
alter database "meta" open resetlogs;
exec dbms_service.delete_service('seeddata');
exec dbms_service.delete_service('seeddataXDB');
alter database rename global_name to "meta.caprion.com";
ALTER TABLESPACE TEMP ADD TEMPFILE '/u02/oradata/meta/temp01.dbf' SIZE 20480K REUSE AUTOEXTEND ON NEXT 640K MAXSIZE UNLIMITED;
select tablespace_name from dba_tablespaces where tablespace_name='USERS';
select sid, program, serial#, username from v$session;
alter database character set INTERNAL_CONVERT AL32UTF8;
alter database national character set INTERNAL_CONVERT AL16UTF16;
alter user sys account unlock identified by "&&sysPassword";
alter user system account unlock identified by "&&systemPassword";
alter system disable restricted session;
