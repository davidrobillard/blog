#!/bin/sh

OLD_UMASK=`umask`
umask 0027
mkdir -p /u01/app/oracle/admin/meta/adump
mkdir -p /u01/app/oracle/admin/meta/dpdump
mkdir -p /u01/app/oracle/admin/meta/pfile
mkdir -p /u01/app/oracle/cfgtoollogs/dbca/meta
mkdir -p /u01/app/oracle/product/11.2.0.3/dbhome_1/dbs
mkdir -p /u01/oradata/meta
mkdir -p /u02/oradata/meta
mkdir -p /u03/oradata/fra
mkdir -p /u03/oradata/meta
umask ${OLD_UMASK}
ORACLE_SID=meta; export ORACLE_SID
PATH=$ORACLE_HOME/bin:$PATH; export PATH
echo You should Add this entry in the /etc/oratab: meta:/u01/app/oracle/product/11.2.0.3/dbhome_1:Y
/u01/app/oracle/product/11.2.0.3/dbhome_1/bin/sqlplus /nolog @/u01/app/oracle/admin/meta/scripts/meta.sql
